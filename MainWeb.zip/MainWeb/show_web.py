import webview
def web_view():
    webview.create_window(" ","http://127.0.0.1:5000",width=1200,height=800)
    webview.start()
web_view()