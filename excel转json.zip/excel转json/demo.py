import webview
def web_view():
    webview.create_window(" ","http://127.0.0.1:5000",width=800,height=600)
    webview.start()
web_view()