import pandas as pd
import json
try:
    file_path = 'data.xlsx'  # 文件路径.d
    raw_data = pd.read_excel(file_path, header=0,keep_default_na=False)  # header=0表示第一行是表头，自动去除。keep_default_na=False防止空值为nan
    print(raw_data)
    nan_data = {}
    file = open('ok.json','w',encoding='utf-8')
    for i in range(1,35):
        for list in raw_data.values:
            data = {
                f"{list[2]}": {
                    f"{list[1]}": {
                        "考号": f"{list[0]}",
                        "学校": "禹城一中",
                        "原始总分":f"{list[4]}",
                        "总分": f"{list[5]}",
                        "市名次": f"{list[6]}",
                        "班名次": f"{list[7]}",
                        "校名次": f"{list[8]}",
                        "语文": {"分数": f"{list[9]}", "转换": "", "名次": f"{list[10]}"},
                        "数学": {"分数": f"{list[11]}", "转换": "", "名次": f"{list[12]}"},
                        "英语": {"分数": f"{list[13]}", "转换": "", "名次": f"{list[14]}"},
                        "物理": {"分数": f"{list[15]}", "名次": f"{list[16]}", "等级": f"{list[17]}",
                                 "转换": f"{list[18]}"},
                        "化学": {"分数": f"{list[19]}", "名次": f"{list[20]}", "等级": f"{list[21]}",
                                 "转换": f"{list[22]}"},
                        "生物": {"分数": f"{list[23]}", "名次": f"{list[24]}", "等级": f"{list[25]}",
                                 "转换": f"{list[26]}"},
                        "政治": {"分数": f"{list[27]}", "名次": f"{list[28]}", "等级": f"{list[29]}",
                                 "转换": f"{list[30]}"},
                        "历史": {"分数": f"{list[31]}", "名次": f"{list[32]}", "等级": f"{list[33]}",
                                 "转换": f"{list[34]}"},
                        "地理": {"分数": f"{list[35]}", "名次": f"{list[36]}", "等级": f"{list[37]}",
                                 "转换": f"{list[38]}"},
                        "小语种": {"分数": f"{list[39]}", '语种': f"{list[40]}"}
                    },
                }
            }

            if f'{i}' == str(list[2]):

                try:
                    nan_data[f'{list[2]}'].update(data[str(list[2])])
                except KeyError:
                    nan_data.setdefault(f"{list[2]}", data[str(list[2])])

            #     # print(data[str(list[2])])

    nan_data = json.dumps(nan_data,ensure_ascii=False)
    print(nan_data)
    print(type(nan_data))
    file.write(str(nan_data))
    print("----成功----")
    file.close()
except:
    print("报错!")



