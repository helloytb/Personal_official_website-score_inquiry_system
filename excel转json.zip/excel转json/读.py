import json
import pprint

file = open('ok.json','r',encoding='utf-8').read()
file = json.loads(file)
print(type(file))
pprint.pprint(file)
while True:
    a = input('班级:')
    b= input('姓名:')
    # print(file[a][b])
    pprint.pprint(file[a][b])
    # print(file['1']['杨子成'])

# chnegji = {
#     "20": {
#         "杨统斌": {
#             "语文": "100",
#             "数学": "99",
#             "英语": "785"
#         },
#         "另一个": {
#             "语文": "10",
#             "数学": "98",
#             "英语": "78"
#         }
#     },
# }
# print(chnegji['20'])